// ═══════════════════════════════════════════════════════
//  Move Editorial Planner — Netlify Serverless Function (v1 format)
//  Uses process.env for env vars (NOT Netlify.env.get which is Edge-only)
//  Handles: Groq AI (free), Meta Graph API, JSONBin storage
// ═══════════════════════════════════════════════════════

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Content-Type': 'application/json',
};

function respond(statusCode, data) {
  return { statusCode, headers: CORS_HEADERS, body: JSON.stringify(data) };
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 204, headers: CORS_HEADERS, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return respond(405, { error: { message: 'Method not allowed' } });
  }

  let body;
  try {
    body = JSON.parse(event.body || '{}');
  } catch {
    return respond(400, { error: { message: 'Body JSON non valido.' } });
  }

  const action = body.action || 'chat';

  // ── AI Chat (Groq or OpenRouter) ──
  if (action === 'chat') {
    const provider = body.provider || 'groq'; // 'groq' or 'openrouter'

    let apiKey, apiUrl, extraHeaders = {};
    if (provider === 'openrouter') {
      apiKey = process.env.OPENROUTER_API_KEY;
      apiUrl = 'https://openrouter.ai/api/v1/chat/completions';
      extraHeaders = { 'HTTP-Referer': process.env.URL || 'https://move-planner.netlify.app', 'X-Title': 'Move Editorial Planner' };
      if (!apiKey) return respond(500, { error: { message: 'OPENROUTER_API_KEY non configurata su Netlify.' } });
    } else {
      apiKey = process.env.GROQ_API_KEY;
      apiUrl = 'https://api.groq.com/openai/v1/chat/completions';
      if (!apiKey) return respond(500, { error: { message: 'GROQ_API_KEY non configurata. Vai su console.groq.com → API Keys, crea una chiave gratuita, poi aggiungila nelle variabili d\'ambiente Netlify. Scope: deve includere "Functions".' } });
    }

    const messages = [...(body.messages || [])];
    if (body.system) messages.unshift({ role: 'system', content: body.system });

    const reqBody = {
      model: body.model || (provider === 'openrouter' ? 'meta-llama/llama-3.3-70b-instruct' : 'llama-3.3-70b-versatile'),
      max_tokens: Math.min(body.max_tokens || 4096, 8192),
      temperature: body.temperature || 0.7,
      messages,
    };

    try {
      const resp = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}`, ...extraHeaders },
        body: JSON.stringify(reqBody),
      });

      const data = await resp.json();

      if (!resp.ok || data.error) {
        const errMsg = data.error?.message || `${provider} HTTP ${resp.status}`;
        return respond(resp.status || 500, { error: { message: errMsg } });
      }

      const text = data.choices?.[0]?.message?.content || '';
      return respond(200, {
        content: [{ type: 'text', text }],
        model: data.model,
        usage: data.usage,
      });
    } catch (e) {
      return respond(502, { error: { message: `Errore ${provider}: ${e.message}` } });
    }
  }

  // ── Meta Graph API Proxy ──
  if (action === 'meta') {
    const token = body.access_token;
    const endpoint = body.endpoint;
    if (!token || !endpoint) {
      return respond(400, { error: { message: 'access_token e endpoint richiesti.' } });
    }
    try {
      const sep = endpoint.includes('?') ? '&' : '?';
      const url = `https://graph.facebook.com/v21.0${endpoint}${sep}access_token=${encodeURIComponent(token)}`;
      const resp = await fetch(url);
      const data = await resp.json();
      return respond(resp.ok ? 200 : resp.status, data);
    } catch (e) {
      return respond(502, { error: { message: 'Errore Meta API: ' + e.message } });
    }
  }

  // ── JSONBin Save ──
  if (action === 'jsonbin-save') {
    const apiKey = process.env.JSONBIN_API_KEY;
    if (!apiKey) {
      return respond(500, { error: { message: 'JSONBIN_API_KEY non configurata su Netlify.' } });
    }
    try {
      let url, method;
      const headers = { 'Content-Type': 'application/json', 'X-Master-Key': apiKey };
      if (body.binId) {
        url = `https://api.jsonbin.io/v3/b/${body.binId}`;
        method = 'PUT';
      } else {
        url = 'https://api.jsonbin.io/v3/b';
        method = 'POST';
        headers['X-Bin-Name'] = 'move-planner-data';
        headers['X-Bin-Private'] = 'true';
      }
      const resp = await fetch(url, { method, headers, body: JSON.stringify(body.data) });
      const data = await resp.json();
      return respond(resp.ok ? 200 : resp.status, data);
    } catch (e) {
      return respond(502, { error: { message: 'Errore JSONBin: ' + e.message } });
    }
  }

  // ── JSONBin Load ──
  if (action === 'jsonbin-load') {
    const apiKey = process.env.JSONBIN_API_KEY;
    if (!apiKey) return respond(500, { error: { message: 'JSONBIN_API_KEY non configurata.' } });
    if (!body.binId) return respond(400, { error: { message: 'binId richiesto.' } });
    try {
      const resp = await fetch(`https://api.jsonbin.io/v3/b/${body.binId}/latest`, {
        headers: { 'X-Master-Key': apiKey },
      });
      const data = await resp.json();
      return respond(resp.ok ? 200 : resp.status, data);
    } catch (e) {
      return respond(502, { error: { message: 'Errore JSONBin: ' + e.message } });
    }
  }

  // ── Config Check ──
  if (action === 'check-config') {
    return respond(200, {
      groq: !!process.env.GROQ_API_KEY,
      openrouter: !!process.env.OPENROUTER_API_KEY,
      jsonbin: !!process.env.JSONBIN_API_KEY,
    });
  }

  return respond(400, { error: { message: 'Azione non riconosciuta: ' + action } });
};
